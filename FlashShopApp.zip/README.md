# FlashShop — Android E-Commerce + PHP API

Monorepo layout: Android app (`app/`), PHP API (`backend/`), MySQL dump (`database/`).

---

## Project structure

### Android (Java + XML)

- **Activities**: Splash, Login, Register, **AdminDashboard**, Main, ProductDetail, Cart, Checkout, OrderHistory, Search, **OrderList** (admin orders)
- **Fragments**: Home, Profile  
- **Networking**: Retrofit + Gson, `BuildConfig.BASE_URL`  
- **Login**: `login.php` uses **form-urlencoded** (`email`, `password`). Response JSON: `status`, `token`, and either `user` (customer) or `admin` (admin app — opens **AdminDashboard** after success).  
- **Session**: `SharedPreferences` via `SessionManager` (tracks `account_type`: `user` vs `admin`)  
- **Material Design 3** theme  

### PHP backend (`backend/api/`)

- JSON responses (`Content-Type: application/json`).  
- **Users** authenticate with `authenticateUser()` (Bearer token, `users` table).  
- **Admins** authenticate with `authenticateAdmin()` (Bearer token, `admin` table).  
- PDO prepared statements on mutating endpoints.  

### MySQL (`database/flashshop_db.sql`)

- **11 tables**: `admin`, `users`, `categories`, `products`, `cart`, `wishlist`, `orders`, `order_items`, `reviews`, `banners`, `notifications`  
- The bundled script **`DROP DATABASE IF EXISTS flashshop_db`** then creates the schema and sample data — **backup before import** if you have real data.

---

## Setup

### 1. Database

```bash
mysql -u root -p < database/flashshop_db.sql
```

Or import `database/flashshop_db.sql` in phpMyAdmin.  
If your host disallows `DROP DATABASE`, edit the file to remove those lines and use an empty schema / manual drop instead.

Ensure `backend/config/db.php` matches your server:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'flashshop_db');
define('DB_USER', 'your_mysql_user');
define('DB_PASS', 'your_mysql_password');
define('BASE_URL', 'http://YOUR_PUBLIC_HOST'); // no trailing path; used for upload URLs
```

### 2. Deploy PHP

Upload so the API is reachable as:

```text
http://YOUR_PUBLIC_IP_OR_DOMAIN/flashshop/api/
```

Example files: `login.php`, `get_products.php`, `admin_orders.php`, etc.

### 3. Android Studio

1. **File → Open** the repo root **`andriod app`** (the folder that contains `app/` and `settings.gradle` / Gradle wrapper — not only the inner `app` module if your IDE expects the project root).
2. Set **`app/build.gradle`** → `BASE_URL` to match your deployed API (same path suffix `/flashshop/api/` if you keep that convention):

```groovy
buildConfigField "String", "BASE_URL", "\"http://YOUR_PUBLIC_IP/flashshop/api/\""
```

Use a host/IP the **phone or emulator can reach** (WLAN IP for a real device, or your VPS public IP). Avoid `localhost` on a physical phone.

3. Sync Gradle and Run.

Cleartext HTTP is enabled in the manifest for dev; prefer HTTPS in production.

---

## Test credentials (sample seed)

Password for **all rows below** matches the bcrypt in the SQL file: plaintext **`password`** (not `admin123` / `password123`).

| Role    | Email               | Password  |
|---------|---------------------|-----------|
| Admin   | admin@flashshop.com | password  |
| Customer| alex@example.com    | password  |
| Customer| jane@example.com    | password  |
| Customer| juan@example.com    | password  |

To change passwords, generate a new hash in PHP: `password_hash('YourPass', PASSWORD_BCRYPT)` and `UPDATE admin` / `UPDATE users`.

---

## Admin app flow

1. Log in with `admin@flashshop.com` + password above.  
2. **AdminDashboard** → **Orders** opens **OrderListActivity** (all orders, status spinner).  
3. Status values in the app: `pending`, `processing`, `completed`, `cancelled`. The API maps **`completed`** to DB `order_status` **`delivered`** (see `update_order_status.php`).

---

## API endpoints (overview)

| Method | Endpoint | Auth | Description |
|--------|----------|------|--------------|
| POST | `login.php` | No | User or admin login; JSON `status`, `token`, `user` \| `admin` |
| POST | `register.php` | No | Register |
| POST | `forgot_password.php` | No | Forgot password |
| POST | `logout.php` | Bearer | Clears token on user or admin |
| GET | `get_products.php` | No | Product listing |
| GET | `get_categories.php` | No | Categories |
| GET | `get_banners.php` | No | Banners |
| POST | `add_to_cart.php` | User | Add to cart |
| GET | `get_cart.php` | User | Cart |
| POST | `update_cart.php` | User | Update cart |
| POST/GET | `wishlist.php` | User | Wishlist |
| POST | `place_order.php` | User | Place order |
| GET | `get_orders.php` | User | Current user’s orders |
| GET | `reviews.php` | Mixed | Reviews |
| POST | `reviews.php` | User | Add review |
| GET | `profile.php` | User | Profile |
| PUT | `profile.php` | User | Update profile |
| GET | `get_notifications.php` | User | Notifications |
| GET | `admin_stats.php` | **Admin** | Aggregated counts: orders, revenue, products, customers |
| GET | `admin_orders.php` | **Admin** | All orders (`user_name`, `total_price`, `status`, …) |
| POST | `update_order_status.php` | **Admin** | JSON `id`, `status` |
| POST | `add_product.php` | **Admin** | Create product |
| POST | `update_product.php` | **Admin** | Update product fields |
| POST | `delete_product.php` | **Admin** | Soft deactivate product (`is_active = 0`) |

---

## Tech stack

| Layer    | Details |
|----------|---------|
| Android  | Java 11, minSdk 24, targetSdk 34, compileSdk 36 |
| Networking | Retrofit 3.x, Gson, OkHttp logging |
| Images   | Glide 5.x |
| Backend  | PHP 8+, PDO, MySQL 8 / MariaDB 10.5+ |
| Auth     | Bearer token (SHA-256), stored server-side with expiry |

---

## Debugging tips

- Logcat tag **`FlashShopAPI`** logs parsed login bodies; OkHttp logs full HTTP bodies in debug builds.  
- If login fails: confirm **`BASE_URL`**, HTTPS vs HTTP, and that `login.php` returns **only JSON** (no PHP warnings HTML).  
- If admin lists fail: ensure the admin row exists and you use the **admin** token from `login.php` (not a customer token).
