<?php
/**
 * FlashShop – Forgot Password
 *
 * Sends a password-reset link via Gmail SMTP (PHPMailer).
 *
 * Install PHPMailer with Composer:
 *   composer require phpmailer/phpmailer
 *
 * Or place PHPMailer's src/ folder inside backend/libs/PHPMailer/src/
 * and the autoload below will find it.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

// ── PHPMailer autoload ──────────────────────────────────────────────────────
// Option A – Composer (recommended)
$composerAutoload = __DIR__ . '/../../vendor/autoload.php';
// Option B – manual download into backend/libs/
$manualAutoload   = __DIR__ . '/../libs/PHPMailer/src/PHPMailer.php';

if (file_exists($composerAutoload)) {
    require_once $composerAutoload;
} elseif (file_exists($manualAutoload)) {
    require_once __DIR__ . '/../libs/PHPMailer/src/Exception.php';
    require_once __DIR__ . '/../libs/PHPMailer/src/PHPMailer.php';
    require_once __DIR__ . '/../libs/PHPMailer/src/SMTP.php';
} else {
    // PHPMailer not installed yet – fail gracefully
    sendResponse(500, false, 'Email service not configured on this server. Please install PHPMailer.');
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// ── Gmail SMTP credentials (edit these) ────────────────────────────────────
define('SMTP_HOST',     'smtp.gmail.com');
define('SMTP_PORT',     587);                         // TLS
define('SMTP_USER',     'hiroshisakai27@gmail.com');      // ← change
define('SMTP_PASS',     'nghzodfhbxpeatow');   // ← 16-char App Password
define('SMTP_FROM',     'hiroshisakai27@gmail.com');      // ← same as SMTP_USER
define('SMTP_FROM_NAME','FlashShop');

// ── Main logic ──────────────────────────────────────────────────────────────
$pdo  = getDBConnection();
$data = getJsonInput();
validateRequired($data, ['email']);

$email = sanitize($data['email']);

// Check users table first, then admin table
$user = null;
$table = null;

$stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE email = ? AND is_active = 1");
$stmt->execute([$email]);
$row = $stmt->fetch();
if ($row) {
    $user  = $row;
    $table = 'users';
}

if (!$user) {
    $stmt = $pdo->prepare("SELECT id, full_name FROM admin WHERE email = ? AND is_active = 1");
    $stmt->execute([$email]);
    $row = $stmt->fetch();
    if ($row) {
        $user  = $row;
        $table = 'admin';
    }
}

// Always respond with the same message to prevent email enumeration
if (!$user) {
    sendResponse(200, true, 'If that email is registered, a reset link has been sent.');
}

// Generate token
$resetToken  = bin2hex(random_bytes(32));
$resetExpiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

$pdo->prepare("UPDATE `$table` SET reset_token = ?, reset_expiry = ? WHERE id = ?")
    ->execute([$resetToken, $resetExpiry, $user['id']]);

// Build reset link – change domain to your real domain
$resetLink = BASE_URL . '/reset-password.php?token=' . $resetToken;

// ── Send email via Gmail SMTP ────────────────────────────────────────────────
$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();
    $mail->Host       = SMTP_HOST;
    $mail->SMTPAuth   = true;
    $mail->Username   = SMTP_USER;
    $mail->Password   = SMTP_PASS;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = SMTP_PORT;

    // Sender / recipient
    $mail->setFrom(SMTP_FROM, SMTP_FROM_NAME);
    $mail->addAddress($email, $user['full_name']);

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'FlashShop – Password Reset Request';
    $mail->Body    = buildResetEmailHtml($user['full_name'], $resetLink);
    $mail->AltBody = "Hi {$user['full_name']},\n\nClick the link below to reset your password (valid 1 hour):\n\n$resetLink\n\nIf you did not request this, ignore this email.\n\nFlashShop Team";

    $mail->send();

    sendResponse(200, true, 'If that email is registered, a reset link has been sent.');

} catch (Exception $e) {
    // Log the real error server-side; never expose SMTP details to the client
    error_log('FlashShop SMTP error: ' . $mail->ErrorInfo);
    sendResponse(500, false, 'Could not send reset email. Please try again later.');
}

// ── Email HTML template ──────────────────────────────────────────────────────
function buildResetEmailHtml(string $name, string $link): string {
    return <<<HTML
    <!DOCTYPE html>
    <html>
    <head><meta charset="UTF-8"></head>
    <body style="font-family:Arial,sans-serif;background:#f4f4f4;margin:0;padding:20px;">
      <div style="max-width:500px;margin:auto;background:#fff;border-radius:8px;padding:32px;">
        <h2 style="color:#F44336;margin-top:0;">FlashShop</h2>
        <p>Hi <strong>{$name}</strong>,</p>
        <p>We received a request to reset your password. Click the button below — the link expires in <strong>1 hour</strong>.</p>
        <div style="text-align:center;margin:32px 0;">
          <a href="{$link}"
             style="background:#F44336;color:#fff;padding:14px 28px;border-radius:6px;
                    text-decoration:none;font-weight:bold;font-size:15px;">
            Reset Password
          </a>
        </div>
        <p style="color:#666;font-size:13px;">
          Or copy and paste this link:<br>
          <a href="{$link}" style="color:#F44336;word-break:break-all;">{$link}</a>
        </p>
        <p style="color:#999;font-size:12px;">
          If you did not request a password reset, please ignore this email.
          Your password will remain unchanged.
        </p>
        <hr style="border:none;border-top:1px solid #eee;">
        <p style="color:#999;font-size:11px;text-align:center;">
          &copy; 2025 FlashShop. All rights reserved.
        </p>
      </div>
    </body>
    </html>
    HTML;
}
