package com.flashshop.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.flashshop.app.R;
import com.flashshop.app.adapters.ProductAdapter;
import com.flashshop.app.api.ApiClient;
import com.flashshop.app.models.*;
import java.util.*;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchActivity extends AppCompatActivity {
    private RecyclerView rv;
    private ProductAdapter adapter;
    private android.os.Handler handler = new android.os.Handler();
    private Runnable searchRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        EditText etSearch = findViewById(R.id.et_search);
        rv = findViewById(R.id.rv_search_results);
        adapter = new ProductAdapter(new ArrayList<>(), product -> {
            Intent intent = new Intent(this, ProductDetailActivity.class);
            intent.putExtra("product", product);
            startActivity(intent);
        });
        rv.setLayoutManager(new GridLayoutManager(this, 2));
        rv.setAdapter(adapter);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                if (searchRunnable != null) handler.removeCallbacks(searchRunnable);
                searchRunnable = () -> search(s.toString().trim());
                handler.postDelayed(searchRunnable, 500);
            }
        });
    }

    private void search(String query) {
        if (query.isEmpty()) { adapter.updateData(new ArrayList<>()); return; }
        ApiClient.getService().getProducts(0, query, 0, 0, 1, 30, "rating", "desc")
                .enqueue(new Callback<ApiResponse<ProductListData>>() {
                    @Override public void onResponse(Call<ApiResponse<ProductListData>> c, Response<ApiResponse<ProductListData>> r) {
                        if (r.isSuccessful() && r.body() != null && r.body().isSuccess()) {
                            adapter.updateData(r.body().getData().products);
                        }
                    }
                    @Override public void onFailure(Call<ApiResponse<ProductListData>> c, Throwable t) {}
                });
    }
}
