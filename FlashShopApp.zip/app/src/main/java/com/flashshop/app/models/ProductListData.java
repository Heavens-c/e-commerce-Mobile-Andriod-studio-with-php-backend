package com.flashshop.app.models;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class ProductListData {
    @SerializedName("products") public List<Product> products;
}

